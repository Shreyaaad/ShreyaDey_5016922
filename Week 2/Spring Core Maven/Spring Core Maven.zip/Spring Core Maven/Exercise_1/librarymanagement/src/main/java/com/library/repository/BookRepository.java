package com.library.repository;

public class BookRepository {
    public void manageBooks() {
        System.out.println("Books are being managed in the repository");
    }
}
