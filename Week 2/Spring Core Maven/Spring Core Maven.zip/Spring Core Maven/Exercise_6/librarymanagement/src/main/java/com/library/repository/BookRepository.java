package com.library.repository;

import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {

    public void saveBook(String bookTitle) {
        // Logic to save the book to a database or any storage
        System.out.println("Saving book: " + bookTitle);
    }

    public String findBook(String bookTitle) {
        // Logic to find and return a book
        // Here we just return a dummy response for demonstration purposes
        return "Found book: " + bookTitle;
    }
}


