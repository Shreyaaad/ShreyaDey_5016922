package com.example.employeemanagementsystem.repository;

import com.example.employeemanagementsystem.entity.Employee;
import com.example.employeemanagementsystem.entity.Department;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
public class EmployeeRepositoryTests {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    @Test
    public void testFindByDepartmentName() {
        Department department = new Department();
        departmentRepository.save(department);

        Employee employee1 = new Employee();
        Employee employee2 = new Employee();
        employeeRepository.save(employee1);
        employeeRepository.save(employee2);

       
    }

    @Test
    public void testFindByEmail() {
        Department department = new Department();
        departmentRepository.save(department);

        Employee employee = new Employee();
        employeeRepository.save(employee);

       
    }
}