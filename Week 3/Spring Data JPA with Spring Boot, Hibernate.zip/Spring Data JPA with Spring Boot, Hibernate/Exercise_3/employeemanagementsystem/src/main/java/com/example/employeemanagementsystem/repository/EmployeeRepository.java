package com.example.employeemanagementsystem.repository;

import com.example.employeemanagementsystem.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    // Derived query methods

    // Find all employees by their department name
    List<Employee> findByDepartmentName(String departmentName);

    // Find an employee by their email
    Employee findByEmail(String email);

    // Find all employees with a specific name
    List<Employee> findByName(String name);
}