package com.example.bookstoreapi.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ContentNegotiationConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.http.MediaType;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void configureContentNegotiation(ContentNegotiationConfigurer configurer) {
        configurer
            .favorPathExtension(true) // Use file extensions in URL to determine media type
            .ignoreAcceptHeader(false) // Read the Accept header to determine media type
            .defaultContentType(MediaType.APPLICATION_JSON) // Default content type
            .mediaType("json", MediaType.APPLICATION_JSON) // JSON media type
            .mediaType("xml", MediaType.APPLICATION_XML); // XML media type
    }
}
